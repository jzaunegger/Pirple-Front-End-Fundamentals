# Project 1 Write-Up

For the Pirple Front End Fundamentals course, I have made a basic page about HP Lovecraft. In this course we have been learning about HTML and how we use it to build web pages. I made mine with the help of Wikipedia to gather information about Lovecraft, and W3Schools to learn more about HTML Tags. There I learned about strong, i, blockquote, strong, more information about meta tags, and iframe tags. I used those along with header, main, footer, and div tags to layout the page. I tried to put in comments to help make the code easier to read. My code works by the browser reading the html tags and using a hypertext processor displays the page on the screen. 

A  Screen Shot of my Reddit Post wijl.

![Screenshot] (Screenshot.png)